# Project 4: Microsoft Sentinel — SIEM/SOAR Detection Engineering

## Scenario

Meridian's security team wants centralized detection and automated response across
identity, endpoint, and cloud signals — tying together Projects 1–3.

## Status

🔲 Not started

## Planned structure

```
project-4-sentinel/
├── README.md
├── screenshots/
├── kql-queries/
└── playbooks/
```

*(Full write-up to follow once this project is underway.)*
