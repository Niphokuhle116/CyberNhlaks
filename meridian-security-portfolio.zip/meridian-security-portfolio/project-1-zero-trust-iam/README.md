# Project 1: Zero Trust IAM Implementation

## Scenario

Meridian Retail Group had an internal audit flag weak identity controls: shared logins,
no MFA enforcement, standing admin access, and no conditional access policies. As the
Identity & Access engineer, I redesigned their access model around Zero Trust
("never trust, always verify") using Microsoft Entra ID and Microsoft 365 E5.

## Objectives

- Enforce MFA across all users
- Replace standing admin access with just-in-time privileged access
- Add adaptive, risk-based access controls
- Maintain emergency access without breaking Zero Trust principles

## Architecture

```
Users/Groups → Conditional Access → Identity Protection (risk signals) → PIM (JIT privileged access)
```

*(Diagram to be added — see [diagrams/](./diagrams/))*

## Environment setup

Licensed the tenant with Microsoft 365 E5 and confirmed license assignment before
building out identities.

![E5 license overview](./screenshots/01-e5-license-overview.png)
![License assignment confirmation](./screenshots/02-license-assignment-confirmation.png)

## What I built

### 1. Test users and department structure

Created department-representative test users under Meridian Retail Group, each with
job title, company name, and department set for realism:

| User | Role | Department |
|---|---|---|
| Finance.user1 | Finance Analyst | Finance |
| IT.admin1 | System Administrator | IT Department |
| Sales.user1 | Sales Representative | Sales Department |
| Breakglass.admin | — | Global Administrator (emergency access) |

![Create user - Finance.user1 identity](./screenshots/03-create-user-finance-user1-identity.png)
![Create user - Finance.user1 job info](./screenshots/04-create-user-finance-user1-job-info.png)
![Create user - Finance.user1 confirmed](./screenshots/05-create-user-finance-user1-confirmed.png)
![Create user - IT.admin1 confirmed](./screenshots/06-create-user-it-admin1-confirmed.png)
![Create user - Sales.user1 confirmed](./screenshots/07-create-user-sales-user1-confirmed.png)

### 2. Break-glass emergency access account

Created a dedicated cloud-only Global Administrator account, kept separate from normal
identities and excluded from Conditional Access policies — standard Zero Trust practice
to avoid a full tenant lockout if a policy misfires.

![Break-glass admin account creation](./screenshots/08-create-breakglass-admin-global-admin.png)

### 3. Resolving Security Defaults vs. Conditional Access

The tenant started with Microsoft's baseline **Security Defaults** enabled. Since custom
Conditional Access policies require Security Defaults to be turned off (they're mutually
exclusive control models), I disabled Security Defaults specifically to move to a
custom Conditional Access approach.

![Security Defaults - initially enabled](./screenshots/09-security-defaults-enabled-initial.png)
![Security Defaults - disabled, reason: moving to Conditional Access](./screenshots/10-security-defaults-disabled-for-ca.png)

### 4. CA001 — Require MFA for All Users

Built as **Report-only** first (to validate scope safely before enforcing), targeting
all users except the break-glass account, applied to all resources, with the grant
control set to require multifactor authentication.

![CA001 - policy creation](./screenshots/11-ca001-policy-creation-name.png)
![CA001 - assignments, all users, report-only](./screenshots/12-ca001-assignments-all-users-report-only.png)
![CA001 - exclude break-glass admin](./screenshots/13-ca001-exclude-breakglass-admin.png)
![CA001 - target all resources](./screenshots/14-ca001-target-resources-all.png)
![CA001 - grant: require MFA](./screenshots/15-ca001-grant-require-mfa.png)
![CA001 - policy details, Report-only](./screenshots/16-ca001-policy-details-report-only.png)

After validating in Report-only mode, moved to switch the policy **On**. Since Security
Defaults must be fully disabled before a Conditional Access policy can be enforced, this
surfaced the same dependency as a checkpoint before final enforcement.

![CA001 - attempting to enable policy On](./screenshots/17-ca001-policy-enabled-on-attempt.png)

### 5. CA002 — Require Compliant Device for Sensitive Apps

Registered a test application (`Meridian-FinanceApp-Test`) to represent a sensitive
Finance-department app, then scoped a Conditional Access policy to that specific
resource requiring the device to be either marked compliant or Microsoft Entra
hybrid-joined.

![App registration - Meridian-FinanceApp-Test](./screenshots/18-app-registration-financeapp-test.png)
![CA002 - target resource: FinanceApp-Test](./screenshots/19-ca002-target-resources-select-app.png)
![CA002 - grant: compliant or hybrid-joined device](./screenshots/20-ca002-grant-compliant-device.png)

### 6. CA003 — MFA Step-Up for Unfamiliar or High-Risk Locations

Configured using Entra ID Protection sign-in risk signals, applying to **High** and
**Medium** risk sign-ins.

![CA003 - sign-in risk: High + Medium](./screenshots/21-ca003-signin-risk-high-medium.png)

### 7. Validating policies with the Conditional Access "What If" tool

Used the built-in simulation tool to confirm policies apply as intended before relying
on live risky sign-ins:

- Simulated a sign-in from South Africa: confirmed CA003 (location-risk policy) does
  **not** apply under that specific test condition, while CA001 and CA002 remain in
  effect — useful for confirming the policy's actual trigger conditions rather than
  assuming.

![What If - CA003 does not apply for this test](./screenshots/22-whatif-ca003-not-apply-south-africa.png)
![What If - 3 policies evaluated](./screenshots/23-whatif-3-policies-apply.png)
![What If - South Africa IP, 2 policies apply](./screenshots/24-whatif-south-africa-2-policies.png)

### 8. Privileged Identity Management (PIM)

Assigned the **User Administrator** role to `IT.admin1` as an **eligible** (not
permanent) assignment via PIM, moving the account from standing admin access to
just-in-time activation.

![PIM - add assignment, User Administrator, IT.admin1](./screenshots/25-pim-add-assignment-it-admin1.png)

### 9. MFA registration

Registered Microsoft Authenticator for test users to validate the end-to-end MFA
enforcement flow.

![MFA registration - Finance.user1](./screenshots/26-mfa-register-finance-user1.png)
![MFA registration complete - IT.admin1](./screenshots/27-mfa-authenticator-added-it-admin1.png)

## Conditional Access Policy Summary

| Policy | Users/Groups | Target | Grant Control | Status |
|---|---|---|---|---|
| CA001 - Require MFA for All Users | All users, excl. break-glass | All resources | Require MFA | Built, moving Report-only → On |
| CA002 - Require Compliant Device for Sensitive Apps | All users, excl. break-glass | Meridian-FinanceApp-Test | Require compliant OR hybrid-joined device | Built |
| CA003 - MFA Step-Up for Unfamiliar/High-Risk Locations | All users, excl. break-glass | All resources | Require MFA on High/Medium sign-in risk | Built, validated via What If |

## Status / Next steps

- [x] Users, groups, and break-glass account created
- [x] Security Defaults disabled in favor of custom Conditional Access
- [x] CA001, CA002, CA003 built and validated with the What If simulator
- [x] PIM eligible assignment configured for IT.admin1
- [x] MFA registration completed for test users
- [ ] Finish moving CA001 fully to enforced (On), confirm no lockout via break-glass test
- [ ] Enable and test Identity Protection user-risk policy (require password change on high risk)
- [ ] Full end-to-end PIM activation test (justification → approval → time-bound access)
- [ ] Architecture diagram
- [ ] Key takeaways write-up

## Key Takeaways

*(To fill in once the project is complete — what this demonstrates about Zero Trust
design decisions, trade-offs made, and what you'd change at enterprise scale.)*
