# Meridian Security Portfolio

A hands-on Microsoft security engineering portfolio built across Azure and Microsoft 365 E5,
simulating the identity, cloud, endpoint, and SIEM security needs of a fictional company,
**Meridian Retail Group**.

## Projects

| # | Project | Stack | Status |
|---|---------|-------|--------|
| 1 | [Zero Trust IAM Implementation](./project-1-zero-trust-iam/) | Entra ID, Conditional Access, PIM, Identity Protection | 🔶 In progress |
| 2 | [Defender for Cloud — CSPM](./project-2-defender-for-cloud/) | Azure, Defender for Cloud | 🔲 Planned |
| 3 | [Defender for Endpoint — EDR](./project-3-defender-for-endpoint/) | Defender for Endpoint | 🔲 Planned |
| 4 | [Microsoft Sentinel — SIEM/SOAR](./project-4-sentinel/) | Sentinel, Log Analytics, Logic Apps | 🔲 Planned |

## Why this portfolio

These projects mirror a real security engagement: identity hardening first (Zero Trust),
then cloud posture, then endpoint detection, then tying it all together in a SIEM — the
same order a security team would typically mature its defenses in.

## About Meridian Retail Group (the scenario)

A fictional mid-size e-commerce company used as the consistent backdrop across all four
projects, to keep the portfolio cohesive rather than four disconnected labs.
