# Project 2: Microsoft Defender for Cloud — Cloud Security Posture & Workload Protection

## Scenario

Meridian Retail Group, migrating its first workloads to Azure, wants visibility into
its cloud security posture before scaling further.

## Status

🔲 Not started

## Planned structure

```
project-2-defender-for-cloud/
├── README.md
├── screenshots/
└── diagrams/
```

*(Full write-up to follow once this project is underway.)*
