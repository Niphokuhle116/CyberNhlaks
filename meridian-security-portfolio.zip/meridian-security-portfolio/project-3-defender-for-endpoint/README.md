# Project 3: Microsoft Defender for Endpoint — EDR & Incident Response

## Scenario

Meridian Retail Group has had a report of suspicious activity on a finance department
laptop. Role: SOC analyst on call — onboard, detect, investigate, contain, and report.

## Status

🔲 Not started

## Planned structure

```
project-3-defender-for-endpoint/
├── README.md
├── screenshots/
└── incident-report.md
```

*(Full write-up to follow once this project is underway.)*
